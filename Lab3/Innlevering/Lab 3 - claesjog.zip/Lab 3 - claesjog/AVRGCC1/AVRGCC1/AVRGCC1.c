/*
 * AVRGCC1.c
 *
 * Created: 05.03.2018 10:01:24
 *  Author: claesjog
 */ 

#include <avr/io.h>

